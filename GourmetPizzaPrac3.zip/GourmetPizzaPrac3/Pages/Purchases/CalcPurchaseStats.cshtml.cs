﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GourmetPizzaPrac3.Models; 
using Microsoft.AspNetCore.Authorization;


namespace GourmetPizzaPrac3.Pages.Purchases
{
   [Authorize(Roles = "Customer")]
    public class CalcPurchaseStatsModel : PageModel
    {
        private readonly GourmetPizzaPrac3.ApplicationDbContext _context;

        public  CalcPurchaseStatsModel(GourmetPizzaPrac3.ApplicationDbContext context)
        {
            _context = context; 
        }

        //store query results 
        public IList<PurchaseStats> PurchStats { get; set; }

        public async Task<ActionResult> OnGetAsync()
        {
            var QuantityGroups = _context.Purchase.GroupBy(p => p.PizzaCount);

            //Perform the grouping query 
            PurchStats = await QuantityGroups
                .Select(g => new PurchaseStats { PizzaCount = g.Key, OrderQuantity = g.Count() })
                .ToListAsync();

            return Page(); 
        }
    }
}