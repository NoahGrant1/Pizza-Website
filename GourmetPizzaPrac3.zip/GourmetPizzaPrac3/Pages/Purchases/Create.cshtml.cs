﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using GourmetPizzaPrac3;
using GourmetPizzaPrac3.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace GourmetPizzaPrac3.Pages.Purchases
{
    //only Authorised users 
    [Authorize(Roles = "Customer")]
    public class CreateModel : PageModel
    {
        private readonly GourmetPizzaPrac3.ApplicationDbContext _context;

        //variable to store drop down items 
        public SelectList PizzaList { get; set; }

        public CreateModel(GourmetPizzaPrac3.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            PizzaList = new SelectList(_context.Pizza, "ID", "Name");
            return Page();
        }

        [BindProperty]
        public Purchase purchase { get; set; }

        [BindProperty]
        public Pizza pizza { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            PizzaList = new SelectList(_context.Pizza, "ID", "Name");

            /*
            if (!ModelState.IsValid) //model state is not valid 
            {
                return Page();
            }
            */

            //get user email and confirm it before doing query 
            var _email = User.FindFirst(ClaimTypes.Name).Value;
            Customer customer = await _context.Customer.FirstOrDefaultAsync(m => m.EmailAddress == _email);
            purchase.CustomerEmail = customer.EmailAddress;

            //calculate total price
            Pizza price = await _context.Pizza.FirstAsync(p => p.ID == purchase.PizzaID);
            // decimal TotalPrice = price.Price * purchase.PizzaCount;
            purchase.TotalCost = price.Price * purchase.PizzaCount;

            //only make purchase if customer email is valid 
            if (customer != null)
            {
                _context.Purchase.Add(purchase);
                await _context.SaveChangesAsync();
            }

            //return details to creation page 
            ViewData["PizzaName"] = price.Name; 
            ViewData["TotalPrice"] = price.Price * purchase.PizzaCount;
            return Page();
        }
    }
}
