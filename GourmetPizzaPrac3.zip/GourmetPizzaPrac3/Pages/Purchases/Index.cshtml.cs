﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GourmetPizzaPrac3;
using GourmetPizzaPrac3.Models;
using System.Security.Claims;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Authorization;

namespace GourmetPizzaPrac3.Pages.Purchases
{
    [Authorize(Roles = "Customer")]
    public class IndexModel : PageModel
    {
        private readonly GourmetPizzaPrac3.ApplicationDbContext _context;

        public IndexModel(GourmetPizzaPrac3.ApplicationDbContext context)
        {
            _context = context;
        }

       
        public IList<Purchase> Purchase { get; set; }
       
        public IList<Pizza> Pizza { get; set; }
       
        public IList<Customer> Customer {get; set;}

        public async Task<ActionResult> OnGetAsync(string sortOrder)
        {
            //apply the sorting order to the columns 
            if(String.IsNullOrEmpty(sortOrder))
            {
                sortOrder = "name_asc"; 
            }

            //switch the order by category 
            var order = (IQueryable<Purchase>)_context.Purchase; 
            switch(sortOrder)
            {
                case "name_asc":
                    order = order.OrderBy(m => m.ThePizza);
                    break;
                case "name_desc":
                    order = order.OrderByDescending(m => m.ThePizza);
                    break;
                case "count_asc":
                    order = order.OrderBy(m => m.PizzaCount);
                    break;
                case "count_desc":
                    order = order.OrderByDescending(m => m.PizzaCount);
                    break;
                case "cost_asc":
                    order = order.OrderBy(m => (double)m.TotalCost);
                    break;
                case "cost_desc":
                    order = order.OrderByDescending(m => (double)m.TotalCost);
                    break;
            }

            //send to view page and alternate between them 
            ViewData["NextPizzaOrder"] = sortOrder != "name_asc" ? "name_asc" : "title_desc";
            ViewData["NextCountOrder"] = sortOrder != "count_asc" ? "count_asc" : "count_desc";
            ViewData["NextPriceOrder"] = sortOrder != "cost_asc" ? "cost_asc" : "cost_desc";

            //get user email 
            string _email = User.FindFirst(ClaimTypes.Name).Value;

            //get user name and create full name for list 
            Customer customer = await _context.Customer.FirstOrDefaultAsync(m => m.EmailAddress == _email);
            ViewData["FullName"] = customer.FirstName + " " + customer.FamilyName;

            //Order the query 
            Purchase = await order
                 .Where(p => p.CustomerEmail == _email)
                 .Include(p => p.ThePizza)
                 .AsNoTracking()
                 .ToListAsync();




            return Page(); 
        }
    }
}
