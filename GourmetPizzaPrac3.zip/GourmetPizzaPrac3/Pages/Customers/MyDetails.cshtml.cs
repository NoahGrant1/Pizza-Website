﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GourmetPizzaPrac3.Models;

namespace GourmetPizzaPrac3.Pages.Customers
{
    [Authorize(Roles = "Customer")]
    public class MyDetailsModel : PageModel
    {
        private readonly GourmetPizzaPrac3.ApplicationDbContext _context;

        public MyDetailsModel(GourmetPizzaPrac3.ApplicationDbContext context)
        {
            _context = context;
        }

        // reference to customer model 
        [BindProperty]
        public CustomerModel Myself { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;

            Customer customer= await _context.Customer.FirstOrDefaultAsync(m => m.EmailAddress == _email);

            if (customer != null)
            {
                // The user has been created in the database
                ViewData["ExistInDB"] = "true";
                Myself = new CustomerModel
                {
                    // Retrieve his/her details for display in the web form
                    FirstName = customer.FirstName,
                    FamilyName = customer.FamilyName,
                    BirthDate = customer.BirthDate,
                    PhoneNumber = customer.PhoneNumber,
                    PostCode = customer.PostCode
                };
            }
            else
            {
                ViewData["ExistInDB"] = "false";
            }

            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;

            Customer customer= await _context.Customer.FirstOrDefaultAsync(m => m.EmailAddress == _email);

            if (customer != null)
            {
                // This ViewData entry is needed in the content file
                // The user has been created in the database
                ViewData["ExistInDB"] = "true";
            }
            else
            {
                ViewData["ExistInDB"] = "false";
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (customer == null)
            {
                // creating a moviegoer object for inserting database
                customer = new Customer();
            }

            // Construct this moviegoer object based on 'Myself'
            customer.EmailAddress = _email;
            customer.FirstName = Myself.FirstName;
            customer.FamilyName= Myself.FamilyName;
            customer.BirthDate = Myself.BirthDate;
            customer.PhoneNumber = Myself.PhoneNumber;
            customer.PostCode = Myself.PostCode; 

            if ((string)ViewData["ExistInDB"] == "true")
            {
                _context.Attach(customer).State = EntityState.Modified;
            }
            else
            {
                _context.Customer.Add(customer);
            }

            try  // catching the conflict of editing this record concurrently
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }

            ViewData["SuccessDB"] = "success";
            return Page();
        }
    }
}