﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GourmetPizzaPrac3;
using GourmetPizzaPrac3.Models;

namespace GourmetPizzaPrac3.Pages.Customers
{
    public class DetailsModel : PageModel
    {
        private readonly GourmetPizzaPrac3.ApplicationDbContext _context;

        public DetailsModel(GourmetPizzaPrac3.ApplicationDbContext context)
        {
            _context = context;
        }

        public Customer Customer { get; set; }

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Customer = await _context.Customer.FirstOrDefaultAsync(m => m.EmailAddress == id);

            if (Customer == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
