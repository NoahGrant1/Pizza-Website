﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GourmetPizzaPrac3
{

    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<GourmetPizzaPrac3.Models.Pizza> Pizza { get; set; }

        public DbSet<GourmetPizzaPrac3.Models.Customer> Customer { get; set; }

        public DbSet<GourmetPizzaPrac3.Models.Purchase> Purchase { get; set; }
    }
}