﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GourmetPizzaPrac3.Data.Migrations
{
    public partial class IntitalCreate4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
