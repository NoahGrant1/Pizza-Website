﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizzaPrac3.Models
{
    //used to display the statistics 
    public class PurchaseStats
    {
        public int OrderQuantity { get; set; }

        public int PizzaCount { get; set; }
    }
}
