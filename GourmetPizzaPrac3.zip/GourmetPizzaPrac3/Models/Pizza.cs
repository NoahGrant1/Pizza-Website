﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizzaPrac3.Models
{
    public class Pizza
    {
        public int ID { get; set; }
        [Required]
        //increased to 21 due to pineapple not fitting in 
        [StringLength(21, MinimumLength = 3)]
        //allows english letters, digits, white space and _
        [RegularExpression(@"^[a-zA-Z\d\s_]{3,21}$")]
        public string Name { get; set; }
        [Display(Name = "Price Each")]
        [Range(5.00, 20.00)]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public ICollection<Purchase> ThePurchase { get; set; }
    }
}
