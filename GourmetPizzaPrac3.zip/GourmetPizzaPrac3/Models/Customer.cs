﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizzaPrac3.Models
{
    public class Customer
    {
        [Required]
        //allows for english characters, hypen and apostrophe 
        [StringLength(20, MinimumLength = 2)]
        [RegularExpression(@"[a-zA-Z-']{2,20}$")]
        public string FamilyName { get; set; }
        [Required]
        //allows for english characters, hypen and apostrophe 
        [StringLength(20, MinimumLength = 2)]
        [RegularExpression(@"[a-zA-Z-']{2,20}$")]
        public string FirstName { get; set; }

        [Display(Name = "Date Of Birth")]
        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        [Key, Required]
        [DataType(DataType.EmailAddress)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]

        public string EmailAddress { get; set; }

        [Required]
        //regex for 04 phone number  with spaces 
        [RegularExpression(@"^04[0-9]{2}\s[0-9]{3}\s[0-9]{3}$", ErrorMessage = "04XX XXX XXX Required")]
        public string PhoneNumber { get; set; }

        [Required]
        [RegularExpression(@"^[0-8]{1}[0-9]{3}$", ErrorMessage = "9 cannot be at the beginning")]
        public string PostCode { get; set; }


        //nagivation links for relationships 
        //one customer can have many purchases 
        public ICollection<Purchase> ThePurchase { get; set; }
    }
}
